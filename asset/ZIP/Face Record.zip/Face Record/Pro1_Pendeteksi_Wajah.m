clear all;
close all;
clc;
warning off;
webcam_op = webcam();
image = snapshot(webcam_op);
detection = vision.CascadeObjectDetector();
imshow(image);

while true
    image = snapshot(webcam_op);
    image2 = rgb2gray(image);
    bbox = step(detection,image2);
    pic = insertObjectAnnotation(image, 'Rectangle', bbox, 'Face');
    imshow(pic);
end
